
package screensframework;

/**
 *
 * @author Rocio Carmona
 */
public interface ControlledScreen {
   
    public void setScreenParent(ScreensController screenPage);
}
